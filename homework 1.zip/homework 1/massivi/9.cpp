#include <iostream>
using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");
    int m, X[100];
    cout << "m: ";
    cin >> m;

    cout << "��������: ";
    for (int i = 0; i < m; i++) cin >> X[i];

    int maxLen = 0, len = 1;

    for (int i = 1; i < m; i++) {
        if ((len % 2 == 1 && X[i] > X[i - 1]) ||
            (len % 2 == 0 && X[i] < X[i - 1])) {
            len++;
        }
        else {
            if (len > maxLen && len > 1) maxLen = len;
            len = 1;
        }
    }

    if (len > maxLen && len > 1) maxLen = len;

    cout << "����� ����: " << maxLen << endl;

    return 0;
}