#include <iostream>
using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");
    double a, b, c;
    cout << "a, b, c: ";
    cin >> a >> b >> c;

    double x = -b / (2 * a);
    double y = a * x * x + b * x + c;

    cout << "�������: (" << x << ", " << y << ")" << endl;
    return 0;
}